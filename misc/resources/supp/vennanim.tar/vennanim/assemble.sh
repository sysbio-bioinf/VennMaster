#!/bin/sh

convert -delay 20 venn-0-start.jpg venn-0-0???.jpg venn-0-9999.jpg image.gif
